const express = require("express");
const app = express();
app.use(express.json());

let tasks = []; // in-memory storage

app.get("/tasks", (req, res) => res.json(tasks));
app.post("/tasks", (req, res) => {
  const task = { id: tasks.length + 1, ...req.body };
  tasks.push(task);
  res.status(201).json(task);
});
app.delete("/tasks/:id", (req, res) => {
  tasks = tasks.filter(t => t.id != req.params.id);
  res.json({ message: "Task deleted" });
});

app.listen(5000, () => console.log("Server running on port 5000 🚀"));
